import csv
import sys
import time
from Adafruit_IO import MQTTClient
import requests
import sensor
import gps
import human_detector
from math import radians, sin, cos, sqrt, atan2


AIO_FEED_ID = ["sensor1", "sensor2", "sensor3", "button1", "button2", "equation", "location"]
AIO_USERNAME = "Multidisciplinary_Project"
AIO_KEY = "aio_dZTr31xI4vz8oLrXs34yXAKIoqkS"
AIO_IDs = ["sensor1", "sensor2", "sensor3", "button1", "button2", "equation", "location"]

global_equation = "x1+x2+x3"
location_to_check = (11.106550, 106.613027)  # VGU


def connected(this_client):
    print("Ket noi thanh cong ...")
    for i in AIO_IDs:
        this_client.subscribe(i)


def subscribe(this_client, userdata, mid, granted_qos):
    print("Subscribe thanh cong ...")


def disconnected(this_client):
    print("Ngat ket noi ...")
    sys.exit(1)


def message(this_client, feed_id, payload):
    print("Nhan du lieu: " + feed_id + " " + payload)

    if feed_id == "equation":
        global global_equation
        global_equation = payload
        print(global_equation)
        return

    if feed_id == "button1":
        if payload == "ON":
            print("Bat den...")
            sensor.send_command("2")
            return

        if payload == "OFF":
            print("Tat den...")
            sensor.send_command("3")
            return


def init_global_equation():
    headers = {}
    aio_url = "https://io.adafruit.com/api/v2/Multidisciplinary_Project/feeds/equation"
    x = requests.get(url=aio_url, headers=headers, verify=False)
    data = x.json()
    global global_equation
    global_equation = data["last_value"]
    print("Get latest value:", global_equation)


# def modify_value(x1, x2, x3):
#     result = eval(global_equation)
#     print(result)
#     return result


def publish_gps_to_adafruit_io(this_latitude, this_longitude):
    # latitude_str = str(latitude)
    # longitude_str = str(longitude)

    aio_headers = {
        'X-AIO-Key': AIO_KEY,
        'Content-Type': 'application/json',
    }
    aio_url = f'https://io.adafruit.com/api/v2/Multidisciplinary_Project/feeds/location/data'
    aio_payload = {
        'value': f'{this_latitude},{this_longitude}',
    }
    response = requests.post(aio_url, headers=aio_headers, json=aio_payload)
    if response.status_code == 200:
        print(f'Published GPS data: Latitude={this_latitude}, Longitude={longitude}')
    else:
        print(f'Failed to publish GPS data. Status code: {response.status_code}')


def calculate_distance(lat1, lon1, lat2, lon2):
    r = 6371.0  # Earth's radius in kilometers

    lat1_rad = radians(lat1)
    lon1_rad = radians(lon1)
    lat2_rad = radians(lat2)
    lon2_rad = radians(lon2)

    d_lon = lon2_rad - lon1_rad
    d_lat = lat2_rad - lat1_rad

    a = sin(d_lat / 2)**2 + cos(lat1_rad) * cos(lat2_rad) * sin(d_lon / 2)**2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))

    this_distance = r * c
    return this_distance


def request_data(cmd):
    sensor.send_command(cmd)
    time.sleep(2)
    temp_hum = sensor.read_serial()

    return temp_hum


client = MQTTClient(AIO_USERNAME, AIO_KEY)

client.on_connect = connected
client.on_disconnect = disconnected
client.on_message = message
client.on_subscribe = subscribe
client.connect()
client.loop_background()
init_global_equation()


on_off_second = 0  # When a certain value is reached, depends on the situation, the AC functions accordingly
mode_second = 0
on_off_tag = 0  # Mark at which condition block the code was run or run
mode_tag = 0
trigger_point = 100
is_on = False  # To tell whether the AC is on or off


counter = 0  # Use to get the index of the below 2 lists
temp_humid_file = open("temperature_humidity.txt", "r")
temp_humid_list = list(csv.reader(temp_humid_file))
temp_humid_length = len(temp_humid_list)
temp_humid_file.close()


def is_previous_on_off_if_block(this_tag):  # Prevent duplication code
    global on_off_tag
    global on_off_second
    if this_tag != on_off_tag:
        on_off_tag = this_tag
        on_off_second = 0
    on_off_second += 10


def is_previous_mode_if_block(this_tag):
    global mode_tag
    global mode_second
    if this_tag != mode_tag:
        mode_tag = this_tag
        mode_second = 0
    mode_second += 10


while True:
    if sensor.USE_REAL_SENSOR_DATA:

        temperature = request_data("0")
        humidity = request_data("1")
        time.sleep(1)
    else:

        #   Generate random value for 'temperature' and 'humidity'
        # temperature, humidity = sensor.generate_random_temp_humid()

        # Read value from files
        temperature = float(temp_humid_list[counter][0].strip())
        humidity = float(temp_humid_list[counter][1].strip())
        counter += 1
        if counter > temp_humid_length:  # Loop back from the beginning when reach the end
            counter = 0

        time.sleep(1)

    human_detector_result = human_detector.detection()

    client.publish("sensor1", temperature)
    client.publish("sensor2", humidity)
    client.publish("ai", human_detector_result)
    time.sleep(2)
    # client.publish("test feed", modify_value(temperature, humidity))

    latitude, longitude = gps.read_gps_data()
    print(f'Latitude: {latitude}, Longitude: {longitude}')
    publish_gps_to_adafruit_io(latitude, longitude)

    distance = calculate_distance(location_to_check[0], location_to_check[1], latitude, longitude)
    human_detector_result = human_detector.detection()

    # ON/OFF Automation logic
    if human_detector_result == "Human presence" and temperature > 20:  # First if block -> tag = 0
        # If the tag is not equal to 0 (the first if block) set 'tag' to 0 and reset 'second' to 0
        # This prevents conflict between each if block. For example, if the 1st 'if block' is only
        # executed half way (second = 200)
        # And the 4th 'if block' is executed, the code should know to set 'second' back to 0 so that the 4th if block
        # can be executed correctly (if 'second' is not set to 0 the instruction will be run immediately, which defeats
        # the 60-second delay logic)
        # But when a 'if block' is executed consecutively, then 'second' should not be set back to 0
        is_previous_on_off_if_block(0)

        if on_off_second > trigger_point/5:
            client.publish("button1", "1")
            on_off_second = 0
            is_on = True

    elif distance <= 1 and temperature > 30:  # Second if block -> tag = 1
        is_previous_on_off_if_block(1)
        if on_off_second > trigger_point + trigger_point/2:
            client.publish("button1", "1")
            on_off_second = 0
            if_on = True

    elif temperature < 24:  # Third if block -> tag = 2
        is_previous_on_off_if_block(2)
        if on_off_second > trigger_point * 9:
            client.publish("button1", "0")
            on_off_second = 0
            is_on = False

    elif distance > 1 and human_detector_result == "Empty":  # Fourth if block -> tag = 3
        is_previous_on_off_if_block(3)
        if on_off_second > trigger_point:
            client.publish("button1", "0")
            on_off_second = 0
            is_on = False

    # Mode Automation logic
    if is_on is True and humidity > 70:
        is_previous_mode_if_block(0)
        if mode_second > trigger_point:
            client.publish("button2", "1")
            mode_second = 0
    elif is_on is False and humidity <= 70:
        is_previous_mode_if_block(1)
        if mode_second > trigger_point:
            client.publish("button2", "0")
            mode_second = 0

    time.sleep(10)

    pass
