import sys
import time
from Adafruit_IO import MQTTClient
import requests
import sensor
import gps
import human_detector
from math import radians, sin, cos, sqrt, atan2


AIO_FEED_ID = ["sensor1", "sensor2", "sensor3", "button1", "button2", "equation", "location"]
AIO_USERNAME = "Multidisciplinary_Project"
AIO_KEY = "aio_jeoa49rlUiJYm1nSxDarn7PamnGO"
AIO_IDs = ["sensor1", "sensor2", "sensor3", "button1", "button2", "equation", "location"]

global_equation = "x1+x2+x3"
location_to_check = (11.106550, 106.613027)  # VGU


def connected(this_client):
    print("Ket noi thanh cong ...")
    for i in AIO_IDs:
        this_client.subscribe(i)


def subscribe(this_client, userdata, mid, granted_qos):
    print("Subscribe thanh cong ...")


def disconnected(this_client):
    print("Ngat ket noi ...")
    sys.exit(1)


def message(this_client, feed_id, payload):
    print("Nhan du lieu: " + payload)

    if feed_id == "equation":
        global global_equation
        global_equation = payload
        print(global_equation)
        return

    if feed_id == "button1":
        if payload == "ON":
            print("Bat den...")
            sensor.send_command("2")
            return

        if payload == "OFF":
            print("Tat den...")
            sensor.send_command("3")
            return


def init_global_equation():
    headers = {}
    aio_url = "https://io.adafruit.com/api/v2/Multidisciplinary_Project/feeds/equation"
    x = requests.get(url=aio_url, headers=headers, verify=False)
    data = x.json()
    global global_equation
    global_equation = data["last_value"]
    print("Get latest value:", global_equation)


# def modify_value(x1, x2, x3):
#     result = eval(global_equation)
#     print(result)
#     return result


def publish_gps_to_adafruit_io(this_latitude, this_longitude):
    # latitude_str = str(latitude)
    # longitude_str = str(longitude)

    aio_headers = {
        'X-AIO-Key': AIO_KEY,
        'Content-Type': 'application/json',
    }
    aio_url = f'https://io.adafruit.com/api/v2/Multidisciplinary_Project/feeds/location/data'
    aio_payload = {
        'value': f'{this_latitude},{this_longitude}',
    }
    response = requests.post(aio_url, headers=aio_headers, json=aio_payload)
    if response.status_code == 200:
        print(f'Published GPS data: Latitude={this_latitude}, Longitude={longitude}')
    else:
        print(f'Failed to publish GPS data. Status code: {response.status_code}')


def calculate_distance(lat1, lon1, lat2, lon2):
    r = 6371.0  # Earth's radius in kilometers

    lat1_rad = radians(lat1)
    lon1_rad = radians(lon1)
    lat2_rad = radians(lat2)
    lon2_rad = radians(lon2)

    d_lon = lon2_rad - lon1_rad
    d_lat = lat2_rad - lat1_rad

    a = sin(d_lat / 2)**2 + cos(lat1_rad) * cos(lat2_rad) * sin(d_lon / 2)**2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))

    this_distance = r * c
    return this_distance


def request_data(cmd):
    sensor.send_command(cmd)
    time.sleep(2)
    temp_hum = sensor.read_serial()

    return temp_hum


client = MQTTClient(AIO_USERNAME, AIO_KEY)

client.on_connect = connected
client.on_disconnect = disconnected
client.on_message = message
client.on_subscribe = subscribe
client.connect()
client.loop_background()
init_global_equation()


second = 0  # When a certain value is reached, depends on the situation, the AC functions accordingly
tag = 0

while True:
    if sensor.USE_REAL_SENSOR_DATA:

        temperature = request_data("0")
        humidity = request_data("1")
        time.sleep(1)
    else:

        # Generate random value for 'temperature' and 'humidity'
        temperature, humidity = sensor.generate_random_temp_humid()
        time.sleep(1)

    human_detector_result = human_detector.detection()

    client.publish("sensor1", temperature)
    client.publish("sensor2", humidity)
    client.publish("ai", human_detector_result)
    time.sleep(2)
    # client.publish("test feed", modify_value(temperature, humidity))

    latitude, longitude = gps.read_gps_data()
    print(f'Latitude: {latitude}, Longitude: {longitude}')
    publish_gps_to_adafruit_io(latitude, longitude)

    distance = calculate_distance(location_to_check[0], location_to_check[1], latitude, longitude)
    human_detector_result = human_detector.detection()

    # Automation logic
    if human_detector_result == "Human_presence" and temperature > 30:
        if tag != 0:
            tag = 0
            second = 0

        second = second + 10
        if second > 300:
            client.publish("button1", "1")
            second = 0

    elif distance <= 1 and temperature > 28:
        if tag != 1:
            tag = 1
            second = 0

        second = second + 10
        if second > 120:
            client.publish("button1", "1")
            second = 0

    elif temperature < 24:
        if tag != 3:
            tag = 3
            second = 0

        second = second + 10
        if second > 900:
            client.publish("button1", "0")
            second = 0

    elif distance > 1 and human_detector_result == "Empty":
        if tag != 4:
            tag = 4
            second = 0

        second = second + 10
        if second > 60:
            client.publish("button1", "0")
            second = 0

    time.sleep(10)

    pass
